"""Download a small, reproducible TACO subset for training.

TACO (Trash Annotations in Context) supplies real-world litter images and
COCO-format bounding boxes.  The full dataset is large; this script downloads
only the first --max-images images that contain at least one supported label.
"""

from __future__ import annotations

import argparse
import json
import os
import urllib.request
from collections import defaultdict
from pathlib import Path


TACO_ANNOTATIONS_URL = (
    "https://raw.githubusercontent.com/pedropro/TACO/master/data/annotations.json"
)


def fetch(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.stat().st_size > 0:
        return
    print(f"Downloading {url}")
    urllib.request.urlretrieve(url, destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="data/taco", help="dataset directory")
    parser.add_argument("--max-images", type=int, default=350)
    args = parser.parse_args()

    root = Path(args.root)
    annotations_path = root / "annotations.json"
    fetch(TACO_ANNOTATIONS_URL, annotations_path)
    annotations = json.loads(annotations_path.read_text())

    category_names = {
        c["id"]: c["name"].lower() for c in annotations["categories"]
    }

    def supported(name: str) -> bool:
        keywords = (
            "paper", "carton", "cardboard", "can", "metal", "foil", "glass",
            "plastic", "polypropylene", "foam", "styrofoam", "food waste",
            "cigarette", "shoe", "unlabeled", "battery",
        )
        return any(k in name for k in keywords)

    supported_ids = {cid for cid, name in category_names.items() if supported(name)}
    anns_by_image: dict[int, list[dict]] = defaultdict(list)
    for ann in annotations["annotations"]:
        if ann.get("iscrowd", 0) == 0 and ann["category_id"] in supported_ids:
            anns_by_image[ann["image_id"]].append(ann)

    selected = [
        image for image in annotations["images"] if image["id"] in anns_by_image
    ][: args.max_images]

    manifest = {
        "source": "TACO - Trash Annotations in Context",
        "source_url": "https://tacodataset.org/",
        "annotations": str(annotations_path),
        "images": [],
    }

    for i, image in enumerate(selected, start=1):
        relative = Path(image["file_name"])
        path = root / "images" / relative
        try:
            fetch(image["flickr_640_url"], path)
            manifest["images"].append(
                {
                    "id": image["id"],
                    "file_name": str(path),
                    "width": image["width"],
                    "height": image["height"],
                }
            )
        except Exception as exc:
            print(f"Skipping {image['file_name']}: {exc}")
        if i % 25 == 0 or i == len(selected):
            print(f"Prepared {i}/{len(selected)} images")

    (root / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"Dataset ready: {len(manifest['images'])} images in {root}")


if __name__ == "__main__":
    main()
