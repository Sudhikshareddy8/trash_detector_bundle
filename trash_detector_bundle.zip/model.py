"""A small grid-based CNN for trash detection.

The model predicts one object per 32x32 grid cell.  It is intentionally
minimal so it can train quickly on a CPU and run on a low-power computer.
"""

from __future__ import annotations

import torch
from torch import nn


CLASS_NAMES = ["paper", "can", "plastic", "glass", "organic", "other"]
NUM_CLASSES = len(CLASS_NAMES)
GRID_SIZE = 7
IMAGE_SIZE = 224


class TinyTrashCNN(nn.Module):
    """~0.35M parameter CNN detector.

    Output shape is [batch, 7, 7, 5 + number_of_classes]:
    tx, ty, tw, th, objectness, class_logits...
    """

    def __init__(self, num_classes: int = NUM_CLASSES) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 3, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 32, 3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 96, 3, stride=2, padding=1),
            nn.BatchNorm2d(96),
            nn.ReLU(inplace=True),
            nn.Conv2d(96, 128, 3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
        )
        self.head = nn.Conv2d(128, 5 + num_classes, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # NCHW -> NHWC makes decoding in the camera script easier.
        return self.head(self.features(x)).permute(0, 2, 3, 1).contiguous()
