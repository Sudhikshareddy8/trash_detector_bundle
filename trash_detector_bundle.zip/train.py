"""Train TinyTrashCNN on TACO bounding boxes.

Example:
    python download_dataset.py --max-images 350
    python train.py --epochs 15

The trained file is written to weights/trash_cnn.pt.
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import cv2
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from model import CLASS_NAMES, GRID_SIZE, IMAGE_SIZE, TinyTrashCNN


def label_for_category(name: str) -> str:
    name = name.lower()
    if "food waste" in name:
        return "organic"
    if any(x in name for x in ("paper", "carton", "cardboard", "tissue", "toilet tube")):
        return "paper"
    if any(x in name for x in ("glass", "broken glass")):
        return "glass"
    if any(x in name for x in ("can", "metal", "foil", "battery", "pop tab")):
        return "can"
    if any(
        x in name
        for x in (
            "plastic", "polypropylene", "foam", "styrofoam", "blister",
            "bag", "wrapper", "film", "lid", "tub", "tupperware",
            "container", "glove", "utensil", "straw", "squeezable",
        )
    ):
        return "plastic"
    return "other"


class TacoDataset(Dataset):
    def __init__(self, samples: list[dict], annotations: dict, train: bool):
        self.samples = samples
        self.train = train
        categories = {c["id"]: c["name"] for c in annotations["categories"]}
        anns_by_image: dict[int, list[dict]] = {}
        for ann in annotations["annotations"]:
            if ann.get("iscrowd", 0) == 0:
                anns_by_image.setdefault(ann["image_id"], []).append(ann)
        self.targets = []
        for image in samples:
            boxes = []
            for ann in anns_by_image.get(image["id"], []):
                x, y, w, h = ann["bbox"]
                if w > 2 and h > 2:
                    boxes.append((x, y, w, h, label_for_category(categories[ann["category_id"]])))
            self.targets.append(boxes)

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int):
        sample = self.samples[index]
        image = cv2.imread(sample["file_name"])
        if image is None:
            raise FileNotFoundError(sample["file_name"])
        h, w = image.shape[:2]
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = cv2.resize(image, (IMAGE_SIZE, IMAGE_SIZE), interpolation=cv2.INTER_AREA)

        target = np.zeros((GRID_SIZE, GRID_SIZE, 5 + len(CLASS_NAMES)), dtype=np.float32)
        for x, y, bw, bh, label in self.targets[index]:
            # TACO's annotation dimensions describe the original Flickr
            # image, while the downloader uses the smaller 640px image.
            scale_x = w / float(sample["width"])
            scale_y = h / float(sample["height"])
            x, bw = x * scale_x, bw * scale_x
            y, bh = y * scale_y, bh * scale_y
            cx = (x + bw / 2) / w
            cy = (y + bh / 2) / h
            nw, nh = bw / w, bh / h
            gx = min(GRID_SIZE - 1, int(cx * GRID_SIZE))
            gy = min(GRID_SIZE - 1, int(cy * GRID_SIZE))
            # Keep the larger annotation if two objects share one cell.
            if target[gy, gx, 4] > 0 and target[gy, gx, 3] >= nh:
                continue
            target[gy, gx, 0] = cx * GRID_SIZE - gx
            target[gy, gx, 1] = cy * GRID_SIZE - gy
            target[gy, gx, 2] = nw
            target[gy, gx, 3] = nh
            target[gy, gx, 4] = 1.0
            target[gy, gx, 5 + CLASS_NAMES.index(label)] = 1.0

        if self.train and random.random() < 0.5:
            image = image[:, ::-1].copy()
            object_cells = np.argwhere(target[:, :, 4] > 0)
            for gy, gx in object_cells:
                target[gy, gx, 0] = 1.0 - target[gy, gx, 0]

        image = torch.from_numpy(image).permute(2, 0, 1).float() / 255.0
        return image, torch.from_numpy(target)


def detection_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    # Decode coordinates with sigmoid so all predictions stay in range.
    box_pred = torch.sigmoid(pred[..., :4])
    obj_pred = pred[..., 4]
    cls_pred = pred[..., 5:]
    box_target = target[..., :4]
    obj_target = target[..., 4]
    cls_target = target[..., 5:].argmax(dim=-1)
    positive = obj_target.bool()

    coord = nn.functional.smooth_l1_loss(
        box_pred[positive], box_target[positive], reduction="mean"
    ) if positive.any() else pred.sum() * 0
    obj_raw = nn.functional.binary_cross_entropy_with_logits(
        obj_pred, obj_target, reduction="none"
    )
    # Most grid cells are empty; down-weight them.
    obj = (obj_raw * (positive.float() * 5.0 + (~positive).float() * 0.25)).mean()
    cls = (
        nn.functional.cross_entropy(cls_pred[positive], cls_target[positive])
        if positive.any() else pred.sum() * 0
    )
    return 5.0 * coord + obj + cls


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default="data/taco")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    root = Path(args.root)
    manifest = json.loads((root / "manifest.json").read_text())
    annotations = json.loads((root / "annotations.json").read_text())
    samples = manifest["images"][:]
    random.shuffle(samples)
    split = max(1, int(len(samples) * 0.85))
    train_set = TacoDataset(samples[:split], annotations, train=True)
    val_set = TacoDataset(samples[split:], annotations, train=False)
    loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=0)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TinyTrashCNN().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    best_val = float("inf")
    Path("weights").mkdir(exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        model.train()
        train_total = 0.0
        for images, targets in loader:
            images, targets = images.to(device), targets.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = detection_loss(model(images), targets)
            loss.backward()
            optimizer.step()
            train_total += loss.item()

        model.eval()
        val_total = 0.0
        with torch.no_grad():
            for images, targets in val_loader:
                val_total += detection_loss(
                    model(images.to(device)), targets.to(device)
                ).item()
        train_avg = train_total / max(1, len(loader))
        val_avg = val_total / max(1, len(val_loader))
        print(f"epoch {epoch:02d}/{args.epochs}  train={train_avg:.4f}  val={val_avg:.4f}")
        if val_avg < best_val:
            best_val = val_avg
            torch.save(
                {
                    "model": model.state_dict(),
                    "classes": CLASS_NAMES,
                    "image_size": IMAGE_SIZE,
                    "grid_size": GRID_SIZE,
                    "dataset": "TACO",
                    "label_mapping": "train.py::label_for_category",
                },
                "weights/trash_cnn.pt",
            )
    print("Saved weights/trash_cnn.pt")


if __name__ == "__main__":
    main()
