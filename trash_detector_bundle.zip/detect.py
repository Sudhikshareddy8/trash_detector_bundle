"""Webcam trash detection with a tiny CNN and a lightweight human detector.

Run:
    python detect.py --weights weights/trash_cnn.pt

Press q to quit.  Trash is drawn with a box and printed as biodegradable or
non-biodegradable.  Human detection uses OpenCV's built-in HOG detector, so it
does not need another large model file.
"""

from __future__ import annotations

import argparse
import time

import cv2
import numpy as np
import torch

from model import CLASS_NAMES, IMAGE_SIZE, GRID_SIZE, TinyTrashCNN


BIODEGRADABLE = {"paper", "organic"}


def nms(detections: list[dict], threshold: float = 0.35) -> list[dict]:
    kept = []
    for detection in sorted(detections, key=lambda x: x["score"], reverse=True):
        if all(
            intersection_over_union(detection["box"], other["box"]) < threshold
            for other in kept
        ):
            kept.append(detection)
    return kept


def intersection_over_union(a, b) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    intersection = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    area_a = max(1, ax2 - ax1) * max(1, ay2 - ay1)
    area_b = max(1, bx2 - bx1) * max(1, by2 - by1)
    return intersection / float(area_a + area_b - intersection + 1e-6)


def predict(model, frame, device, confidence=0.45):
    height, width = frame.shape[:2]
    resized = cv2.resize(frame, (IMAGE_SIZE, IMAGE_SIZE), interpolation=cv2.INTER_AREA)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
    tensor = torch.from_numpy(rgb).permute(2, 0, 1).float().div(255).unsqueeze(0)
    with torch.no_grad():
        output = model(tensor.to(device))[0].cpu()
    output[..., :4] = output[..., :4].sigmoid()
    output[..., 4] = output[..., 4].sigmoid()
    detections = []
    for gy in range(GRID_SIZE):
        for gx in range(GRID_SIZE):
            cell = output[gy, gx]
            objectness = float(cell[4])
            class_score, class_id = torch.softmax(cell[5:], dim=0).max(dim=0)
            score = objectness * float(class_score)
            if score < confidence:
                continue
            cx = (gx + float(cell[0])) / GRID_SIZE * width
            cy = (gy + float(cell[1])) / GRID_SIZE * height
            bw = float(cell[2]) * width
            bh = float(cell[3]) * height
            box = (
                max(0, int(cx - bw / 2)),
                max(0, int(cy - bh / 2)),
                min(width - 1, int(cx + bw / 2)),
                min(height - 1, int(cy + bh / 2)),
            )
            detections.append(
                {"box": box, "score": score, "label": CLASS_NAMES[int(class_id)]}
            )
    return nms(detections)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", default="weights/trash_cnn.pt")
    parser.add_argument("--camera", type=int, default=0)
    # This tiny model is trained on a small TACO subset; 0.20 is a practical
    # starting point. Raise it to 0.30-0.40 to reduce false positives.
    parser.add_argument("--confidence", type=float, default=0.20)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    checkpoint = torch.load(args.weights, map_location=device)
    model = TinyTrashCNN(num_classes=len(checkpoint.get("classes", CLASS_NAMES)))
    model.load_state_dict(checkpoint["model"])
    model.to(device).eval()

    human_detector = cv2.HOGDescriptor()
    human_detector.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
    camera = cv2.VideoCapture(args.camera)
    if not camera.isOpened():
        raise RuntimeError("Could not open the camera. Try --camera 1.")

    last_printed = {}
    last_human = False
    previous = time.time()
    while True:
        ok, frame = camera.read()
        if not ok:
            break

        detections = predict(model, frame, device, args.confidence)
        humans, _ = human_detector.detectMultiScale(
            frame, winStride=(8, 8), padding=(8, 8), scale=1.05
        )
        human_seen = len(humans) > 0
        if human_seen and not last_human:
            print("HUMAN")
        last_human = human_seen

        for detection in detections:
            x1, y1, x2, y2 = detection["box"]
            label = detection["label"]
            kind = "BIODEGRADABLE" if label in BIODEGRADABLE else "NON-BIODEGRADABLE"
            print_key = f"{label}:{kind}"
            if time.time() - last_printed.get(print_key, 0) > 1.5:
                print(f"{label.upper()} -> {kind}")
                last_printed[print_key] = time.time()
            color = (40, 180, 40) if kind == "BIODEGRADABLE" else (40, 80, 220)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(
                frame, f"{label} {detection['score']:.2f}", (x1, max(20, y1 - 8)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2,
            )

        for x, y, w, h in humans:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 180, 0), 2)
            cv2.putText(
                frame, "human", (x, max(20, y - 8)), cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (255, 180, 0), 2,
            )

        fps = 1.0 / max(1e-6, time.time() - previous)
        previous = time.time()
        cv2.putText(
            frame, f"FPS: {fps:.1f} | q: quit", (10, 25),
            cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2,
        )
        cv2.imshow("Tiny CNN Trash Detector", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    camera.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
