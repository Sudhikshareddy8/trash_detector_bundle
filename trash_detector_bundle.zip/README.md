# Tiny CNN trash detector

This is a small, CPU-friendly object detector for a webcam.  It draws
bounding boxes around broad trash types and prints:

```text
PAPER -> BIODEGRADABLE
CAN -> NON-BIODEGRADABLE
HUMAN
```

## Dataset

The training script uses [TACO — Trash Annotations in
Context](https://tacodataset.org/), a public dataset with real-world litter
images and COCO-format bounding boxes.  `download_dataset.py` downloads a
small subset (350 images by default), so training is much faster than using
the full dataset.  TACO has fine-grained labels; `train.py` groups them into
`paper`, `can`, `plastic`, `glass`, `organic`, and `other`.

## Install and train

```bash
python -m pip install -r requirements.txt
python download_dataset.py --max-images 350
python train.py --epochs 15
```

The trained checkpoint is `weights/trash_cnn.pt`.  It contains the model
state, class names, image size, and grid size.

## Run

```bash
python detect.py --weights weights/trash_cnn.pt
```

Press `q` to close the window.  Use `--camera 1` if the default camera is not
the right one.  The default confidence is `0.20` because this checkpoint is
trained on a small subset; use `--confidence 0.30` or higher to reduce false
positives.  A real camera is needed for `detect.py`; for a video file,
replace `cv2.VideoCapture(args.camera)` with `cv2.VideoCapture("video.mp4")`.

## Design notes

The detector is a six-convolution CNN with a 7x7 prediction grid and about
0.35 million parameters.  This is deliberately minimal and quick to train,
but it is not as accurate as a large detector.  It can miss small or
overlapping objects, especially because the minimal grid predicts at most one
object per grid cell.

Human detection uses OpenCV's built-in HOG people detector.  This avoids
adding another large neural-network weight file while keeping the webcam
example lightweight.